import "./App.css";
import Additem from "./Home/add item/additem";

function App() {
  return (
    <div className="Main">
      <div className="Home">
        {/* {alert("HEllo world App.js")} */}
        <Additem/>
      </div>
    </div>
  );
}

export default App;
